#include <stdio.h>

int main()
{
	char* message = "HelloWorld\n";
	printf(message);
	return 0;
}
